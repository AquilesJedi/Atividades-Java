import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ConversorMoedaSimples {

    private static final Map<String, Double> taxasDeCambio = new HashMap<>();

    static {
        taxasDeCambio.put("BRL", 5.25);
        taxasDeCambio.put("EUR", 0.93);
        taxasDeCambio.put("GBP", 0.81);
        taxasDeCambio.put("USD", 1.0);
    }

    public static double converterMoeda(double valor, String moedaOrigem, String moedaDestino) {
        if (!taxasDeCambio.containsKey(moedaOrigem) || !taxasDeCambio.containsKey(moedaDestino)) {
            System.out.println("Moeda inválida.");
            return -1;
        }

        double taxaOrigem = taxasDeCambio.get(moedaOrigem);
        double taxaDestino = taxasDeCambio.get(moedaDestino);

        double valorEmUSD = valor / taxaOrigem;
        return valorEmUSD * taxaDestino;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Moedas disponíveis:");
        System.out.println("1. BRL - Real Brasileiro");
        System.out.println("2. EUR - Euro");
        System.out.println("3. GBP - Libra Esterlina");
        System.out.println("4. USD - Dólar Americano");

        System.out.print("\nDigite o valor a ser convertido: ");
        double valor = scanner.nextDouble();

        System.out.print("\nDigite a moeda de origem (BRL, EUR, GBP, USD): ");
        String moedaOrigem = scanner.next().toUpperCase();

        System.out.print("\nDigite a moeda de destino (BRL, EUR, GBP, USD): ");
        String moedaDestino = scanner.next().toUpperCase();

        double valorConvertido = converterMoeda(valor, moedaOrigem, moedaDestino);

        if (valorConvertido != -1) {
            System.out.printf("\n%.2f %s é equivalente a %.2f %s\n", valor, moedaOrigem, valorConvertido, moedaDestino);
        }

        scanner.close();
    }
}
