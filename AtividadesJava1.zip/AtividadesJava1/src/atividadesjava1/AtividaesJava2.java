public class AtividaesJava2 {
    public static void main(String[] args) {
        double media1 = (8 + 9 + 7) / 3.0;
        double media2 = (4 + 5 + 6) / 3.0;
        
        double soma = media1 + media2;
        double mediaDasMedias = soma / 2;

        System.out.println("Média 1: " + media1);
        System.out.println("Média 2: " + media2);
        System.out.println("Soma: " + soma);
        System.out.println("Média das médias: " + mediaDasMedias);
    }
}
